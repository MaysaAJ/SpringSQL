package com.example.projetmaysa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetMaysaApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjetMaysaApplication.class, args);
    }

}
