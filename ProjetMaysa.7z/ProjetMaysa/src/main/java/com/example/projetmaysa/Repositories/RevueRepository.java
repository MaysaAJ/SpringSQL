package com.example.projetmaysa.Repositories;

import com.example.projetmaysa.Models.Revue;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RevueRepository extends JpaRepository<Revue, Integer> {

}
